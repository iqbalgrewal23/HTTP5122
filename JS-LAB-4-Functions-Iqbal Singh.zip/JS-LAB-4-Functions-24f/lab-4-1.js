﻿//#### LAB 4 - FUNCTIONS ####
//PART 1:  PROGRAM ALERT FUNCTION


//################## CREATE YOUR FUNCTION

function coursePopup(courseCode,coursename){
    alert("this course code "+courseCode+"is "+coursename);
}



//################## TEST YOUR FUNCTION
coursePopup("HTTP5121","WebDesign");
coursePopup("HTTP5122","front end web devlopment ");
coursePopup("IXD5106","Interaction Design");